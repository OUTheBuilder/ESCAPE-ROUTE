# OU Escape Route — Hybrid Android workspace (ChatGPT-assisted)

## Current changes
- Android application ID and namespace: `com.ou.escaperoute`.
- Android display name: **OU Escape Route**.
- Preserved the compiled web client assets and Capacitor Android project from the supplied ZIP.
- Added `.github/workflows/build-android.yml` to build a debug APK on GitHub Actions and upload it as an artifact when successful.
- Removed the visible “Made with Floot” badge and tracking script from packaged HTML shell files where present.

## Important limitation
This is **not yet a fully independent application**. The ZIP contains compiled web bundles, not the original editable React pages/components or server source. The client bundle includes references to `https://escaperoute.floot.app`, and backend/auth/database features may still depend on services not included in the ZIP. Changing the Android package ID or removing a badge does not remove those dependencies.

## Build status
An APK has **not** been produced or tested in this environment. The local Gradle attempt could not download Gradle because this environment could not resolve `services.gradle.org` (`UnknownHostException`). The GitHub Actions workflow is provided as the next build route, but it has not yet run; no successful build or on-device functional test is claimed.

## Build on GitHub
1. Upload this project into a GitHub repository, preserving the `.github/workflows/build-android.yml` file.
2. Open the repository's **Actions** tab.
3. Run **Build OU Escape Route Android APK**.
4. If the workflow succeeds, download `OU-Escape-Route-debug-apk` from the run's **Artifacts** section. The APK inside is a debug APK for testing, not a Play Store release.

## Remaining work for a truly standalone app
1. Recover editable client/server source or reconstruct the application from the compiled bundles.
2. Replace server calls with an independently hosted backend and configure authentication/database/secrets.
3. Verify launch, sign-in, game navigation, Premium Account, social links, saved data, and offline/error handling.
4. Build successfully, install on an Android device, and test the actual features.
